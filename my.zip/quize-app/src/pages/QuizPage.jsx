import React, { useState } from "react";
import quizData from "../data/quizData";
import ResultPage from "./ResultPage";

function QuizPage() {
  const [selected, setSelected] = useState(Array(quizData.length).fill(null));
  const [submitted, setSubmitted] = useState(false);
  const [currentQ, setCurrentQ] = useState(0);

  const handleSelect = (optionIndex) => {
    const updated = [...selected];
    updated[currentQ] = optionIndex;
    setSelected(updated);

    // Move to next question after short delay
    if (currentQ < quizData.length - 1) {
      setTimeout(() => setCurrentQ(currentQ + 1), 400);
    } else {
      setTimeout(() => setSubmitted(true), 400);
    }
  };

  const score = selected.reduce((acc, answer, i) => {
    return acc + (answer === quizData[i].correct ? 5 : 0);
  }, 0);

  return (
    <div className="container py-5">
      <h2 className="mb-4 text-center">🎓 Web Development Quiz</h2>

      {submitted ? (
        <ResultPage selected={selected} quizData={quizData} score={score} />
      ) : (
        <>
          <div className="card shadow mb-4">
            <div className="card-body">
              <h5>Q{currentQ + 1}: {quizData[currentQ].question}</h5>
              {quizData[currentQ].options.map((option, i) => {
                const isSelected = selected[currentQ] === i;
                return (
                  <button
                    key={i}
                    onClick={() => handleSelect(i)}
                    className={`btn w-100 text-start my-2 ${
                      isSelected ? "btn-dark text-white" : "btn-outline-secondary"
                    }`}
                  >
                    {option}
                  </button>
                );
              })}
            </div>
          </div>

          <p className="text-center text-muted">
            Question {currentQ + 1} of {quizData.length}
          </p>
        </>
      )}
    </div>
  );
}

export default QuizPage;
