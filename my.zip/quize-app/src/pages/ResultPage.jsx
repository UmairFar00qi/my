import React from "react";

function ResultPage({ selected, quizData, score }) {
  const pass = score >= 20;

  return (
    <div className="card shadow p-4">
      <h3 className="mb-3 text-center">
        {pass ? "✅ You Passed!" : "❌ You Failed!"}
      </h3>
      <p className="text-center">Your Score: <strong>{score} / 25</strong></p>

      <table className="table table-bordered table-striped mt-4">
        <thead className="table-dark">
          <tr>
            <th>Q#</th>
            <th>Your Answer</th>
            <th>Correct Answer</th>
            <th>Result</th>
          </tr>
        </thead>
        <tbody>
          {quizData.map((q, i) => {
            const isCorrect = selected[i] === q.correct;
            return (
              <tr key={i} className={isCorrect ? "table-success" : "table-danger"}>
                <td>{i + 1}</td>
                <td>{q.options[selected[i]] || "Not Attempted"}</td>
                <td>{q.options[q.correct]}</td>
                <td>{isCorrect ? "✅ Correct" : "❌ Wrong"}</td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}

export default ResultPage;
