import React from "react";
import QuizPage from "./pages/QuizPage";
import ResultCard from "./components/ResultCard";



function App() {
  return <QuizPage />;
  {quizData.map((q, i) => (
    <ResultCard key={i} question={q} selectedAnswer={selected[i]} index={i} />
  ))}
}

export default App;
