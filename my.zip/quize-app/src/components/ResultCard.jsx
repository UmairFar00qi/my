import React from "react";

function ResultCard({ question, selectedAnswer, index }) {
  const isCorrect = selectedAnswer === question.correct;

  return (
    <div className={`card mb-3 shadow-sm ${isCorrect ? "border-success" : "border-danger"}`}>
      <div className="card-body">
        <h5 className="card-title">Q{index + 1}: {question.question}</h5>
        <p>
          <strong>Your Answer: </strong>
          <span className={isCorrect ? "text-success" : "text-danger"}>
            {selectedAnswer !== null ? question.options[selectedAnswer] : "Not Attempted"}
          </span>
        </p>
        {!isCorrect && (
          <p>
            <strong>Correct Answer: </strong>
            <span className="text-success">{question.options[question.correct]}</span>
          </p>
        )}
      </div>
    </div>
  );
}

export default ResultCard;
