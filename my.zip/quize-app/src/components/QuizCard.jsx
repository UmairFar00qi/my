import React from "react";

function QuizCard({ question, index, selected, setSelected, submitted }) {
  return (
    <div className="card mb-4 shadow">
      <div className="card-body">
        <h5 className="card-title">Q{index + 1}: {question.question}</h5>
        {question.options.map((option, i) => {
          const isCorrect = question.correct === i;
          const isWrong = selected[index] === i && i !== question.correct;

          let btnClass = "btn btn-outline-secondary w-100 text-start mb-2";

          if (submitted) {
            if (isCorrect) btnClass = "btn btn-success w-100 text-start mb-2";
            else if (isWrong) btnClass = "btn btn-danger w-100 text-start mb-2";
            else btnClass += " disabled";
          }

          return (
            <button
              key={i}
              className={btnClass}
              disabled={submitted}
              onClick={() => setSelected(index, i)}
            >
              {option}
            </button>
          );
        })}
      </div>
    </div>
  );
}

export default QuizCard;
