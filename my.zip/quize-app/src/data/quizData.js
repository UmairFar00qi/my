const quizData = [
    {
      question: "What does HTML stand for?",
      options: ["Hyper Trainer Marking Language", "Hyper Text Markup Language", "Hyper Tool Multi Language", "High Text Machine Language"],
      correct: 1,
    },
    {
      question: "What is CSS used for?",
      options: ["Styling websites", "Creating databases", "Server-side scripting", "Encrypting files"],
      correct: 0,
    },
    {
      question: "What does JS stand for?",
      options: ["Java Syntax", "Java Source", "JavaScript", "Jumbo Source"],
      correct: 2,
    },
    {
      question: "Which tag is used to create a link in HTML?",
      options: ["<link>", "<a>", "<href>", "<url>"],
      correct: 1,
    },
    {
      question: "Which CSS property changes text color?",
      options: ["font-color", "color", "text-color", "background"],
      correct: 1,
    },
  ];
  
  export default quizData;
  